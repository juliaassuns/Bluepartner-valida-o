const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'bluepartner.db');

let db;

function getDb() {
    if (!db) {
        // Garante que o diretório data/ existe
        const fs = require('fs');
        const dir = path.dirname(DB_PATH);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }

        db = new sqlite3.Database(DB_PATH);
        db.run('PRAGMA journal_mode=WAL');
        db.run('PRAGMA foreign_keys=ON');
    }
    return db;
}

function initDatabase() {
    return new Promise((resolve, reject) => {
        const db = getDb();

        db.serialize(() => {
            // Tabela de pedidos
            db.run(`
                CREATE TABLE IF NOT EXISTS pedidos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    pedido_id TEXT NOT NULL UNIQUE,
                    token TEXT NOT NULL,
                    cliente TEXT NOT NULL,
                    cnpj TEXT NOT NULL,
                    revenda TEXT DEFAULT 'ingram',
                    status TEXT DEFAULT 'PENDENTE',
                    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
                    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            `);

            // Tabela de licenças do pedido
            db.run(`
                CREATE TABLE IF NOT EXISTS licencas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    pedido_id TEXT NOT NULL,
                    produto TEXT NOT NULL,
                    qtd INTEGER NOT NULL DEFAULT 1,
                    duracao TEXT NOT NULL DEFAULT '12 meses NCE',
                    preco TEXT NOT NULL,
                    FOREIGN KEY (pedido_id) REFERENCES pedidos(pedido_id)
                )
            `);

            // Tabela de logs de validação
            db.run(`
                CREATE TABLE IF NOT EXISTS logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    pedido_id TEXT NOT NULL,
                    token TEXT NOT NULL,
                    revenda TEXT,
                    timestamp TEXT NOT NULL,
                    ip TEXT,
                    user_agent TEXT,
                    status TEXT NOT NULL DEFAULT 'VALIDADO',
                    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            `);

            // Índices
            db.run(`CREATE INDEX IF NOT EXISTS idx_pedidos_pedido_id ON pedidos(pedido_id)`);
            db.run(`CREATE INDEX IF NOT EXISTS idx_pedidos_token ON pedidos(token)`);
            db.run(`CREATE INDEX IF NOT EXISTS idx_licencas_pedido_id ON licencas(pedido_id)`);
            db.run(`CREATE INDEX IF NOT EXISTS idx_logs_pedido_id ON logs(pedido_id)`, (err) => {
                if (err) reject(err);
                else resolve();
            });
        });
    });
}

// Helpers promisificados
function dbGet(sql, params = []) {
    return new Promise((resolve, reject) => {
        getDb().get(sql, params, (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
}

function dbAll(sql, params = []) {
    return new Promise((resolve, reject) => {
        getDb().all(sql, params, (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
        });
    });
}

function dbRun(sql, params = []) {
    return new Promise((resolve, reject) => {
        getDb().run(sql, params, function (err) {
            if (err) reject(err);
            else resolve({ lastID: this.lastID, changes: this.changes });
        });
    });
}

module.exports = { getDb, initDatabase, dbGet, dbAll, dbRun };
