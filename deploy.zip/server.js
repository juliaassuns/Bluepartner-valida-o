require('dotenv').config();

const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const XLSX = require('xlsx');
const { initDatabase, dbGet, dbAll, dbRun } = require('./db');
const { criarConviteGDAP, isGdapConfigured } = require('./gdap');

// Multer config — upload to temp dir
const upload = multer({ dest: path.join(__dirname, 'data', 'uploads'), limits: { fileSize: 10 * 1024 * 1024 } });

const app = express();
const PORT = process.env.PORT || 3000;

// ===== MIDDLEWARE =====
app.use(cors({
    origin: process.env.CORS_ORIGIN || '*',
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type']
}));

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Request logging
app.use((req, res, next) => {
    const ts = new Date().toISOString();
    console.log(`[${ts}] ${req.method} ${req.url}`);
    next();
});

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// ===== MIDDLEWARE: Validação de Token =====
async function validateToken(req, res, next) {
    const { pedidoId, token } = req.params;

    if (!pedidoId || !token) {
        return res.status(400).json({ error: 'pedidoId e token são obrigatórios' });
    }

    // Sanitização básica
    if (!/^[A-Za-z0-9_-]+$/.test(pedidoId) || !/^[A-Za-z0-9_-]+$/.test(token)) {
        return res.status(400).json({ error: 'Formato de pedidoId ou token inválido' });
    }

    try {
        const pedido = await dbGet(
            'SELECT * FROM pedidos WHERE pedido_id = ? AND token = ?',
            [pedidoId, token]
        );

        if (!pedido) {
            return res.status(404).json({ error: 'Pedido não encontrado ou token inválido' });
        }

        req.pedido = pedido;
        next();
    } catch (err) {
        console.error('Erro na validação de token:', err);
        return res.status(500).json({ error: 'Erro interno ao validar token' });
    }
}

// ===== ROTAS API =====

/**
 * GET /api/pedido/:pedidoId/:token
 * Retorna dados do pedido com licenças após validar token
 */
app.get('/api/pedido/:pedidoId/:token', validateToken, async (req, res) => {
    try {
        const pedido = req.pedido;
        const licencas = await dbAll(
            'SELECT produto, qtd, duracao, preco FROM licencas WHERE pedido_id = ?',
            [pedido.pedido_id]
        );

        res.json({
            cliente: pedido.cliente,
            cnpj: pedido.cnpj,
            pedidoId: pedido.pedido_id,
            revenda: pedido.revenda,
            status: pedido.status,
            licencas: licencas
        });
    } catch (err) {
        console.error('Erro ao buscar pedido:', err);
        res.status(500).json({ error: 'Erro interno ao buscar dados do pedido' });
    }
});

/**
 * POST /api/validar
 * Salva log completo da validação
 */
app.post('/api/validar', async (req, res) => {
    try {
        const { pedidoId, token, revenda, timestamp, status } = req.body;

        if (!pedidoId || !token) {
            return res.status(400).json({ error: 'pedidoId e token são obrigatórios' });
        }

        // Captura IP real (considera proxy reverso)
        const ip = req.headers['x-forwarded-for']
            || req.headers['x-real-ip']
            || req.connection?.remoteAddress
            || req.socket?.remoteAddress
            || 'unknown';

        const userAgent = req.headers['user-agent'] || 'unknown';
        const logTimestamp = timestamp || new Date().toISOString();
        const logStatus = status || 'VALIDADO';

        // Insere log
        const result = await dbRun(
            `INSERT INTO logs (pedido_id, token, revenda, timestamp, ip, user_agent, status)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [pedidoId, token, revenda || 'unknown', logTimestamp, ip, userAgent, logStatus]
        );

        // Atualiza status do pedido
        await dbRun(
            `UPDATE pedidos SET status = 'VALIDADO', atualizado_em = CURRENT_TIMESTAMP 
             WHERE pedido_id = ?`,
            [pedidoId]
        );

        console.log(`✅ Validação registrada: ${pedidoId} via ${revenda} | IP: ${ip}`);

        res.json({
            success: true,
            logId: result.lastID,
            message: 'Validação registrada com sucesso'
        });
    } catch (err) {
        console.error('Erro ao salvar validação:', err);
        res.status(500).json({ error: 'Erro interno ao salvar validação' });
    }
});

/**
 * POST /api/pedidos
 * Cria um novo pedido e gera link único para enviar ao cliente
 */
app.post('/api/pedidos', async (req, res) => {
    try {
        const { cliente, cnpj, revenda } = req.body;

        if (!cliente || !cnpj) {
            return res.status(400).json({ error: 'Nome do cliente e CNPJ são obrigatórios' });
        }

        const revendaVal = (revenda || 'ingram').toLowerCase();
        if (!['ingram', 'tds'].includes(revendaVal)) {
            return res.status(400).json({ error: 'Revenda deve ser "ingram" ou "tds"' });
        }

        // Gera pedidoId incremental: PED + timestamp curto
        const count = await dbGet('SELECT COUNT(*) as total FROM pedidos');
        const num = (count.total + 1).toString().padStart(5, '0');
        const pedidoId = `PED${num}`;

        // Gera token único (10 chars alfanuméricos)
        const crypto = require('crypto');
        const token = crypto.randomBytes(5).toString('hex');

        await dbRun(
            'INSERT INTO pedidos (pedido_id, token, cliente, cnpj, revenda) VALUES (?, ?, ?, ?, ?)',
            [pedidoId, token, cliente.trim(), cnpj.trim(), revendaVal]
        );

        console.log(`📋 Novo pedido criado: ${pedidoId} → ${cliente} (${revendaVal})`);

        res.json({
            success: true,
            pedidoId,
            token,
            cliente: cliente.trim(),
            cnpj: cnpj.trim(),
            revenda: revendaVal,
            link: `/?pedidoId=${pedidoId}&token=${token}&revenda=${revendaVal}`
        });
    } catch (err) {
        console.error('Erro ao criar pedido:', err);
        res.status(500).json({ error: 'Erro interno ao criar pedido' });
    }
});

/**
 * GET /api/pedido-completo/:pedidoId
 * Retorna pedido com token (uso interno admin)
 */
app.get('/api/pedido-completo/:pedidoId', async (req, res) => {
    try {
        const pedido = await dbGet(
            'SELECT pedido_id, token, cliente, cnpj, revenda, status FROM pedidos WHERE pedido_id = ?',
            [req.params.pedidoId]
        );
        if (!pedido) return res.status(404).json({ error: 'Não encontrado' });
        res.json(pedido);
    } catch (err) {
        res.status(500).json({ error: 'Erro interno' });
    }
});

/**
 * PUT /api/pedidos/:pedidoId
 * Edita um pedido existente
 */
app.put('/api/pedidos/:pedidoId', async (req, res) => {
    try {
        const { pedidoId } = req.params;
        const { cliente, cnpj, revenda } = req.body;

        const pedido = await dbGet('SELECT * FROM pedidos WHERE pedido_id = ?', [pedidoId]);
        if (!pedido) return res.status(404).json({ error: 'Pedido não encontrado' });

        const newCliente = (cliente || pedido.cliente).trim();
        const newCnpj = (cnpj || pedido.cnpj).trim();
        const newRevenda = (revenda || pedido.revenda).toLowerCase();

        if (!['ingram', 'tds'].includes(newRevenda)) {
            return res.status(400).json({ error: 'Revenda deve ser "ingram" ou "tds"' });
        }

        await dbRun(
            'UPDATE pedidos SET cliente = ?, cnpj = ?, revenda = ?, atualizado_em = CURRENT_TIMESTAMP WHERE pedido_id = ?',
            [newCliente, newCnpj, newRevenda, pedidoId]
        );

        console.log(`✏️ Pedido editado: ${pedidoId}`);
        res.json({ success: true, pedidoId, cliente: newCliente, cnpj: newCnpj, revenda: newRevenda });
    } catch (err) {
        console.error('Erro ao editar pedido:', err);
        res.status(500).json({ error: 'Erro interno ao editar pedido' });
    }
});

/**
 * GET /api/licencas/:pedidoId
 * Lista licenças de um pedido (uso admin)
 */
app.get('/api/licencas/:pedidoId', async (req, res) => {
    try {
        const licencas = await dbAll(
            'SELECT id, pedido_id, produto, qtd, duracao, preco FROM licencas WHERE pedido_id = ? ORDER BY id ASC',
            [req.params.pedidoId]
        );
        res.json({ pedidoId: req.params.pedidoId, total: licencas.length, licencas });
    } catch (err) {
        console.error('Erro ao buscar licenças:', err);
        res.status(500).json({ error: 'Erro ao buscar licenças' });
    }
});

/**
 * POST /api/licencas/:pedidoId
 * Adiciona uma licença a um pedido
 */
app.post('/api/licencas/:pedidoId', async (req, res) => {
    try {
        const { pedidoId } = req.params;
        const { produto, qtd, duracao, preco } = req.body;

        if (!produto || !preco) {
            return res.status(400).json({ error: 'Produto e preço são obrigatórios' });
        }

        const pedido = await dbGet('SELECT id FROM pedidos WHERE pedido_id = ?', [pedidoId]);
        if (!pedido) return res.status(404).json({ error: 'Pedido não encontrado' });

        const result = await dbRun(
            'INSERT INTO licencas (pedido_id, produto, qtd, duracao, preco) VALUES (?, ?, ?, ?, ?)',
            [pedidoId, produto.trim(), qtd || 1, duracao || '12 meses NCE', preco.trim()]
        );

        console.log(`📦 Licença adicionada ao pedido ${pedidoId}: ${produto}`);
        res.json({ success: true, id: result.lastID, pedidoId, produto: produto.trim() });
    } catch (err) {
        console.error('Erro ao adicionar licença:', err);
        res.status(500).json({ error: 'Erro interno ao adicionar licença' });
    }
});

/**
 * DELETE /api/licencas/:licencaId
 * Remove uma licença específica
 */
app.delete('/api/licencas/:licencaId', async (req, res) => {
    try {
        const result = await dbRun('DELETE FROM licencas WHERE id = ?', [req.params.licencaId]);
        if (result.changes === 0) return res.status(404).json({ error: 'Licença não encontrada' });
        res.json({ success: true, message: 'Licença removida' });
    } catch (err) {
        console.error('Erro ao remover licença:', err);
        res.status(500).json({ error: 'Erro interno' });
    }
});

/**
 * POST /api/proposta/:pedidoId
 * Upload de proposta (CSV, XLSX, XLS) e importa itens como licenças
 */
app.post('/api/proposta/:pedidoId', upload.single('arquivo'), async (req, res) => {
    try {
        const { pedidoId } = req.params;
        const pedido = await dbGet('SELECT * FROM pedidos WHERE pedido_id = ?', [pedidoId]);
        if (!pedido) {
            if (req.file) fs.unlinkSync(req.file.path);
            return res.status(404).json({ error: 'Pedido não encontrado' });
        }
        if (!req.file) return res.status(400).json({ error: 'Nenhum arquivo enviado' });

        const ext = path.extname(req.file.originalname).toLowerCase();
        let items = [];

        if (ext === '.csv') {
            // Parse CSV
            const raw = fs.readFileSync(req.file.path, 'utf-8');
            const lines = raw.split(/\r?\n/).filter(l => l.trim());
            if (lines.length < 2) {
                fs.unlinkSync(req.file.path);
                return res.status(400).json({ error: 'Arquivo CSV vazio ou sem dados' });
            }
            // Detect separator
            const sep = lines[0].includes(';') ? ';' : ',';
            const headers = lines[0].split(sep).map(h => h.trim().toLowerCase().replace(/["']/g, ''));
            
            for (let i = 1; i < lines.length; i++) {
                const cols = lines[i].split(sep).map(c => c.trim().replace(/^"|"$/g, ''));
                if (cols.length < 2) continue;
                const item = mapColumns(headers, cols);
                if (item.produto) items.push(item);
            }
        } else if (['.xlsx', '.xls'].includes(ext)) {
            // Parse Excel
            const workbook = XLSX.readFile(req.file.path);
            const sheetName = workbook.SheetNames[0];
            const sheet = workbook.Sheets[sheetName];
            const rows = XLSX.utils.sheet_to_json(sheet, { defval: '' });

            if (!rows.length) {
                fs.unlinkSync(req.file.path);
                return res.status(400).json({ error: 'Planilha vazia' });
            }

            const headers = Object.keys(rows[0]).map(h => h.toLowerCase().trim());
            for (const row of rows) {
                const cols = Object.values(row).map(v => String(v).trim());
                const item = mapColumns(headers, cols);
                if (item.produto) items.push(item);
            }
        } else {
            fs.unlinkSync(req.file.path);
            return res.status(400).json({ error: 'Formato não suportado. Use CSV, XLSX ou XLS.' });
        }

        // Clean up file
        fs.unlinkSync(req.file.path);

        if (!items.length) {
            return res.status(400).json({ error: 'Nenhum item encontrado na proposta. Verifique se as colunas estão corretas.' });
        }

        // Insert all items as licenses
        let inserted = 0;
        for (const item of items) {
            await dbRun(
                'INSERT INTO licencas (pedido_id, produto, qtd, duracao, preco) VALUES (?, ?, ?, ?, ?)',
                [pedidoId, item.produto, item.qtd, item.duracao, item.preco]
            );
            inserted++;
        }

        console.log(`[PROPOSTA] ${inserted} itens importados para ${pedidoId}`);
        res.json({ success: true, imported: inserted, items });
    } catch (err) {
        console.error('Erro ao processar proposta:', err);
        if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
        res.status(500).json({ error: 'Erro ao processar arquivo: ' + err.message });
    }
});

/**
 * Helper: map column headers to fields
 */
function mapColumns(headers, cols) {
    const find = (...keywords) => {
        const idx = headers.findIndex(h => keywords.some(k => h.includes(k)));
        return idx >= 0 ? cols[idx] : '';
    };

    const produto = find('produto', 'product', 'item', 'descri', 'nome', 'licen', 'name', 'sku', 'oferta', 'offer');
    const qtdRaw = find('qtd', 'quant', 'qty', 'seats', 'usu', 'licen');
    const duracao = find('dura', 'period', 'vigencia', 'prazo', 'term', 'billing') || '12 meses NCE';
    const preco = find('preco', 'preço', 'price', 'valor', 'value', 'custo', 'cost', 'unit');

    return {
        produto: produto || '',
        qtd: parseInt(qtdRaw) || 1,
        duracao: duracao || '12 meses NCE',
        preco: preco || '—'
    };
}

/**
 * DELETE /api/pedidos/:pedidoId
 * Remove um pedido
 */
app.delete('/api/pedidos/:pedidoId', async (req, res) => {
    try {
        const { pedidoId } = req.params;
        await dbRun('DELETE FROM licencas WHERE pedido_id = ?', [pedidoId]);
        await dbRun('DELETE FROM logs WHERE pedido_id = ?', [pedidoId]);
        const result = await dbRun('DELETE FROM pedidos WHERE pedido_id = ?', [pedidoId]);
        if (result.changes === 0) {
            return res.status(404).json({ error: 'Pedido não encontrado' });
        }
        res.json({ success: true, message: `Pedido ${pedidoId} removido` });
    } catch (err) {
        console.error('Erro ao remover pedido:', err);
        res.status(500).json({ error: 'Erro interno' });
    }
});

/**
 * GET /api/logs/:pedidoId
 * Retorna logs de validação de um pedido (uso interno)
 */
app.get('/api/logs/:pedidoId', async (req, res) => {
    try {
        const logs = await dbAll(
            'SELECT * FROM logs WHERE pedido_id = ? ORDER BY criado_em DESC',
            [req.params.pedidoId]
        );
        res.json({ pedidoId: req.params.pedidoId, total: logs.length, logs });
    } catch (err) {
        console.error('Erro ao buscar logs:', err);
        res.status(500).json({ error: 'Erro ao buscar logs' });
    }
});

/**
 * GET /api/pedidos
 * Lista todos os pedidos (uso interno/admin)
 */
app.get('/api/pedidos', async (req, res) => {
    try {
        const pedidos = await dbAll(
            'SELECT pedido_id, cliente, cnpj, revenda, status, criado_em, atualizado_em FROM pedidos ORDER BY criado_em DESC'
        );
        res.json({ total: pedidos.length, pedidos });
    } catch (err) {
        console.error('Erro ao listar pedidos:', err);
        res.status(500).json({ error: 'Erro ao listar pedidos' });
    }
});

// ===== ROTAS GDAP =====

/**
 * GET /api/gdap/status
 * Verifica se o GDAP está configurado
 */
app.get('/api/gdap/status', (req, res) => {
    res.json({
        configured: isGdapConfigured(),
        partnerName: process.env.GDAP_PARTNER_NAME || 'Blue Partner',
    });
});

/**
 * POST /api/gdap/criar-convite
 * Cria relação GDAP e retorna link de convite
 * Body (opcional): { displayName, duration }
 */
app.post('/api/gdap/criar-convite', async (req, res) => {
    try {
        if (!isGdapConfigured()) {
            return res.status(503).json({
                error: 'GDAP não configurado',
                message: 'Defina GDAP_TENANT_ID, GDAP_CLIENT_ID e GDAP_CLIENT_SECRET no .env',
            });
        }

        const { displayName, duration } = req.body || {};

        const result = await criarConviteGDAP({ displayName, duration });

        res.json({
            success: true,
            ...result,
        });
    } catch (err) {
        console.error('❌ Erro GDAP:', err.message);
        res.status(500).json({
            error: 'Erro ao criar convite GDAP',
            message: err.message,
        });
    }
});

// ===== SPA FALLBACK =====
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});
// Qualquer rota não-API e não-admin serve o index.html (landing page do cliente)
app.get('*', (req, res) => {
    if (!req.path.startsWith('/api/')) {
        res.sendFile(path.join(__dirname, 'public', 'index.html'));
    }
});

// ===== ERROR HANDLER =====
app.use((err, req, res, next) => {
    console.error('Erro não tratado:', err);
    res.status(500).json({ error: 'Erro interno do servidor' });
});

// ===== START =====
async function start() {
    try {
        await initDatabase();
        console.log('📦 Banco de dados inicializado');

        app.listen(PORT, () => {
            console.log('');
            console.log('═══════════════════════════════════════════════════');
            console.log('  🚀 BluePartner Validação Server');
            console.log(`  🌐 http://localhost:${PORT}`);
            console.log('═══════════════════════════════════════════════════');
            console.log('');
            console.log('  Links de teste:');
            console.log(`  📋 http://localhost:${PORT}/?pedidoId=PED12345&token=xyz789abcd&revenda=ingram`);
            console.log(`  📋 http://localhost:${PORT}/?pedidoId=PED67890&token=abc123defg&revenda=tds`);
            console.log(`  📋 http://localhost:${PORT}/?pedidoId=PED11111&token=mnop456qrs&revenda=ingram`);
            console.log('');
            console.log('  API:');
            console.log(`  GET  /api/pedido/:id/:token`);
            console.log(`  POST /api/validar`);
            console.log(`  GET  /api/logs/:pedidoId`);
            console.log(`  GET  /api/pedidos`);
            console.log('');
            console.log('  GDAP:');
            console.log(`  GET  /api/gdap/status`);
            console.log(`  POST /api/gdap/criar-convite`);
            if (!isGdapConfigured()) {
                console.log('  ⚠️  GDAP não configurado — preencha GDAP_* no .env');
            } else {
                console.log('  ✅ GDAP configurado');
            }
            console.log('');
        });
    } catch (err) {
        console.error('❌ Falha ao iniciar servidor:', err);
        process.exit(1);
    }
}

start();
